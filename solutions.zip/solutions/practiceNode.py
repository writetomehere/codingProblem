import json

class Node:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None
    def __repr__(self):
        return str(self.data)

def serialize(root):
    if not root:
        return None

node_a = Node('a')
node_b = Node('b')
node_c = Node('c')
node_d = Node('d')
node_e = Node('e')
node_f = Node('f')
node_g = Node('g')
node_a.left =  node_b
node_a.right = node_c
node_b.left  = node_d
node_b.right = node_e
node_c.left = node_f
node_c.right = node_g


serialized_a = serialize(node_a)        



# class CFG:
#     def __init__(self, graph):
#         self.graph = graph
#         self.ppl = len(graph)
#         self.jobs = len(graph[0])
#     # DFS
#     def bpm (self, u, matchR, seen):
#         for v in range(self.jobs):
#             if self.graph[u][v] and seen[v] == False:
#                 seen[v] = True
#                 if matchR[v] == -1 or self.bpm(matchR[v], matchR, seen):
#                     matchR[v] =u
#                     return True
#         return False
#     def maxBPM(self):
#         matchR = [-1] * self.jobs
#         result = 0 
#         for i in range (self.ppl):
#             seen = [False] * self.jobs
#             if self.bpm(i,matchR, seen):
#                 result +=1
#         return result



# bpGraph =[[1, 0, 0, 0, 0, 0],
#           [1, 0, 0, 1, 0, 0],
#           [0, 0, 1, 0, 0, 0],
#           [0, 0, 1, 1, 0, 0],
#           [0, 0, 0, 0, 0, 0],
#           [0, 0, 0, 0, 0, 1]]
         
 
# g = CFG(bpGraph)
# print ("Maximum number of applicants that can get job is %d " % g.maxBPM())