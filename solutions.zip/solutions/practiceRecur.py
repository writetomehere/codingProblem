sum  = []

def sum_recur(curr, acc):
    return acc if curr == 11 else sum_recur(curr+1, acc+curr)


# print(sum_recur(1,1))


def attach1(input_list):
    if input_list == []:
        return 0
    else: 
        head = input_list[0]
        next = input_list[1:]
        return head + attach1(next)      
print (attach1([1,2,3]))
