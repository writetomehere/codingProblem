# Solution

* Stream the million numbers into a heap
* `O(log(n))` to insert each one
